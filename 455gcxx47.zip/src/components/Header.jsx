function Header() {
  return (
    <header>
      <h1 style={{ color: "blue", textAlign: "center" }}>
        Student Management System
      </h1>
    </header>
  );
}

export default Header;